"""
PragMind Agentic Hub — Entry Point
===================================
Run with:
    python main.py
or:
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload

API docs available at:
    http://localhost:8000/docs
"""

import sys
import os

# Ensure project root is on the Python path
sys.path.insert(0, os.path.dirname(__file__))

import uvicorn
from api.app import app  # noqa: F401 — expose for uvicorn import string

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
