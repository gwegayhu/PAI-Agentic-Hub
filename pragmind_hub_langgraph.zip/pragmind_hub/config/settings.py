import os
from dotenv import load_dotenv

load_dotenv()

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
MODEL_NAME = os.getenv("MODEL_NAME", "claude-sonnet-4-20250514")
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "4096"))
FORGE_MAX_TOKENS = int(os.getenv("FORGE_MAX_TOKENS", "8192"))

# Escalation phrases to detect in agent responses
ESCALATION_PHRASES = [
    "ESCALATION REQUIRED",
    "CLARIFICATION REQUIRED",
    "ANOMALY ALERT",
    "DRAFT — REQUIRES PRAGMIND REVIEW",
]
