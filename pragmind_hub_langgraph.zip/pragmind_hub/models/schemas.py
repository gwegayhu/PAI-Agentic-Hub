from pydantic import BaseModel, Field
from typing import Literal, Optional
from enum import Enum


class AgentName(str, Enum):
    AXIOM = "axiom"
    SAGE = "sage"
    ATLAS = "atlas"
    PULSE = "pulse"
    FORGE = "forge"


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class RunAgentRequest(BaseModel):
    agent: AgentName
    message: str = Field(..., min_length=1, description="User input to send to the agent")
    history: list[ChatMessage] = Field(
        default_factory=list,
        description="Prior conversation turns for multi-turn context"
    )


class EscalationFlag(BaseModel):
    triggered: bool
    phrase: Optional[str] = None
    type: Optional[Literal["escalation", "clarification", "anomaly", "draft"]] = None


class RunAgentResponse(BaseModel):
    agent: AgentName
    response: str
    escalation: EscalationFlag


class HubRouteRequest(BaseModel):
    message: str = Field(..., description="Free-form message — the hub will route to the correct agent")
    history: list[ChatMessage] = Field(default_factory=list)


class HubRouteResponse(BaseModel):
    routed_to: AgentName
    routing_reason: str
    response: str
    escalation: EscalationFlag
